const {
  test, expect, testAddress, appleJuice, register, login, logout, openAccount, openAccountPage,
  expectAccountEmail, openPrivacyPage, openOrdersPage, saveAddress, saveCard, savedCardRow,
  startCheckout, chooseAddressAndDelivery,
} = require('./juice-shop');

const changedPassword = 'Updated!2026';
const testAvatar = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l2cAAAAASUVORK5CYII=',
  'base64',
);

test.describe.configure({ mode: 'parallel' });

test.describe('Авторизация', () => {
  test('Регистрация нового пользователя', async ({ page, account }) => {
    await test.step('Зарегистрировать аккаунт через форму', () => register(page, account));
    await test.step('Войти с данными нового аккаунта', async () => {
      await login(page, account);
      await expectAccountEmail(page, account.email);
    });
  });

  test('Вход и выход', async ({ page, registeredAccount }) => {
    await test.step('Войти и проверить адрес почты в меню аккаунта', async () => {
      await login(page, registeredAccount);
      await expectAccountEmail(page, registeredAccount.email);
    });
    await test.step('Выйти и проверить доступность входа', async () => {
      await logout(page);
      await openAccount(page);
      await expect(page.getByRole('menuitem', { name: 'Go to login page' }), 'После выхода в меню снова виден пункт входа').toBeVisible();
    });
  });

  test('Флажок «Запомнить меня» сохраняется после выхода', async ({ page, registeredAccount }) => {
    await test.step('Войти с включённым флажком «Запомнить меня»', () => login(page, registeredAccount, true));
    await test.step('Выйти и снова открыть форму входа', async () => {
      await logout(page);
      await openAccountPage(page, 'Go to login page');
    });
    await test.step('Проверить состояние флажка', async () => {
      const remember = page.getByRole('checkbox', { name: 'Checkbox to stay logged in or not logged in' });
      await expect(remember, 'Флажок «Запомнить меня» остался отмеченным').toBeChecked();
    });
  });

  test('Сессия сохраняется после обновления страницы', async ({ signedInPage: page, registeredAccount }) => {
    await test.step('Обновить каталог и открыть профиль', async () => {
      await page.reload();
      await openAccountPage(page, 'Go to user profile');
    });
    await test.step('Убедиться, что открывается профиль того же пользователя', async () => {
      await expect(page, 'Профиль доступен после обновления каталога').toHaveURL(/\/profile$/);
      await expect(page.getByLabel('Disabled - Text field for the email'), 'В профиле сохранился адрес почты пользователя')
        .toHaveValue(registeredAccount.email);
    });
  });
});

test.describe('Профиль', () => {
  test('Просмотр данных покупателя', async ({ signedInPage: page, registeredAccount }) => {
    await test.step('Открыть профиль из меню аккаунта', () => openAccountPage(page, 'Go to user profile'));
    await test.step('Проверить заголовок, почту и роль покупателя', async () => {
      await expect(page.getByRole('heading', { name: 'User Profile' }), 'Открылась страница профиля').toBeVisible();
      await expect(page.getByLabel('Disabled - Text field for the email'), 'Отображается почта текущего пользователя')
        .toHaveValue(registeredAccount.email);
      await expect(page.getByLabel('Disabled - Text field for the role'), 'Отображается роль покупателя').toHaveValue('customer');
    });
  });

  test('Новое имя сохраняется в профиле', async ({ signedInPage: page }) => {
    const username = 'Workshop Buyer';
    await test.step('Ввести и сохранить новое имя', async () => {
      await openAccountPage(page, 'Go to user profile');
      await page.getByLabel('Text field for the username').fill(username);
      await page.getByRole('button', { name: 'Button to save/set the username' }).click();
      await expect(page.getByRole('paragraph').filter({ hasText: username }), 'Новое имя появилось под аватаром').toBeVisible();
    });
    await test.step('Обновить профиль и проверить, что имя сохранилось', async () => {
      await page.reload();
      await expect(page.getByLabel('Text field for the username'), 'В поле имени указано сохранённое значение').toHaveValue(username);
    });
  });

  test('Загруженный аватар отображается после повторного открытия профиля', async ({ signedInPage: page }) => {
    const image = page.getByRole('img', { name: 'profile picture' });
    await test.step('Открыть профиль и загрузить тестовую картинку', async () => {
      await openAccountPage(page, 'Go to user profile');
      await page.getByLabel('Input for selecting the profile picture').setInputFiles({
        name: 'workshop-avatar.png',
        mimeType: 'image/png',
        buffer: testAvatar,
      });
      await page.getByRole('button', { name: 'Button to upload the profile picture' }).click();
      await expect(image, 'Профиль использует загруженную картинку').toHaveAttribute('src', /\/uploads\/\d+\.png$/);
    });
    await test.step('Обновить профиль и проверить, что аватар загружается', async () => {
      await page.reload();
      await expect(image, 'Путь к загруженному аватару сохранился').toHaveAttribute('src', /\/uploads\/\d+\.png$/);
      await expect.poll(() => image.evaluate(element => element.naturalWidth), {
        message: 'Загруженный аватар отображается с ожидаемой шириной в один пиксель',
      }).toBe(1);
    });
  });
});

test.describe('Безопасность', () => {
  test('Смена пароля и вход с новым паролем', async ({ signedInPage: page, registeredAccount }) => {
    await test.step('Ввести текущий пароль и сохранить новый', async () => {
      await openPrivacyPage(page, 'Go to change password page');
      await page.getByLabel('Field to enter the current password').fill(registeredAccount.password);
      await page.getByLabel('Field for the new password').fill(changedPassword);
      await page.getByLabel('Field to repeat the new password').fill(changedPassword);
      await page.getByRole('button', { name: 'Button to confirm the change' }).click();
      await expect(page.getByText('Your password was successfully changed.'), 'Магазин подтвердил смену пароля').toBeVisible();
    });
    await test.step('Повторно войти с новым паролем', async () => {
      await logout(page);
      await login(page, { ...registeredAccount, password: changedPassword });
      await expectAccountEmail(page, registeredAccount.email);
    });
  });

  test('Восстановление пароля через контрольный вопрос', async ({ page, registeredAccount }) => {
    await test.step('Задать новый пароль через форму восстановления', async () => {
      await page.getByRole('link', { name: 'Forgot your password?' }).click();
      await page.getByLabel('Email address field').fill(registeredAccount.email);
      const answer = page.getByLabel('Field for the answer to the security question');
      await expect(answer, 'Показан контрольный вопрос, выбранный при регистрации').toHaveAttribute('placeholder', registeredAccount.question);
      await answer.fill(registeredAccount.answer);
      await page.getByLabel('Field for New Password', { exact: true }).fill(changedPassword);
      await page.getByLabel('Field to confirm the new password').fill(changedPassword);
      await page.getByRole('button', { name: 'Button to confirm the changes' }).click();
      await expect(page.getByRole('status'), 'Магазин подтвердил восстановление пароля').toContainText('Your password was successfully changed.');
    });
    await test.step('Войти с восстановленным паролем', async () => {
      await login(page, { ...registeredAccount, password: changedPassword });
      await expectAccountEmail(page, registeredAccount.email);
    });
  });

  test('Несовпадающие пароли блокируют сохранение', async ({ signedInPage: page, registeredAccount }) => {
    await test.step('Ввести разные значения нового пароля и подтверждения', async () => {
      await openPrivacyPage(page, 'Go to change password page');
      await page.getByLabel('Field to enter the current password').fill(registeredAccount.password);
      await page.getByLabel('Field for the new password').fill(changedPassword);
      const repeatPassword = page.getByLabel('Field to repeat the new password');
      await repeatPassword.fill('Different!2026');
      await repeatPassword.blur();
    });
    await test.step('Проверить сообщение об ошибке и блокировку сохранения', async () => {
      await expect(page.getByText('Passwords do not match'), 'В форме видна ошибка о несовпадении паролей').toBeVisible();
      const submit = page.getByRole('button', { name: 'Button to confirm the change' });
      await expect(submit, 'Кнопка сохранения заблокирована').toBeDisabled();
    });
  });
});

test.describe('Персональные данные', () => {
  test('Просмотр политики конфиденциальности', async ({ signedInPage: page }) => {
    await test.step('Открыть политику конфиденциальности из меню аккаунта', () => openPrivacyPage(page, 'Go to privacy policy page'));
    await test.step('Проверить заголовок и раздел о сборе данных', async () => {
      await expect(page.getByRole('heading', { name: 'Privacy Policy', exact: true }), 'Открылась политика конфиденциальности').toBeVisible();
      const collection = page.getByRole('heading', { name: 'A. Information Collection And Use' });
      await expect(collection, 'Виден раздел о сборе и использовании данных').toBeVisible();
    });
  });

  test('Экспорт данных текущего пользователя в JSON', async ({ signedInPage: page, registeredAccount }) => {
    const exportPage = await test.step('Запросить экспорт в формате JSON', async () => {
      await openPrivacyPage(page, 'Go to data export page');
      await page.getByRole('radio', { name: 'Export Option JSON' }).click();
      const [popup] = await Promise.all([
        page.waitForEvent('popup'),
        page.getByRole('button', { name: 'Button to send the request' }).click(),
      ]);
      return popup;
    });
    await test.step('Проверить почту пользователя в выгруженных данных', async () => {
      const body = exportPage.locator('body');
      await expect(body, 'Экспорт открылся в новом окне и содержит почту пользователя').toContainText(registeredAccount.email);
      expect(JSON.parse(await body.textContent()), 'В поле почты указан адрес текущего пользователя')
        .toHaveProperty('email', registeredAccount.email);
    });
  });

  test('Запрос на удаление данных и завершение сессии', async ({ signedInPage: page, registeredAccount }) => {
    await test.step('Подтвердить почту и отправить запрос на удаление данных', async () => {
      await openPrivacyPage(page, 'Go to data subject page');
      await page.getByLabel('Confirm Email Address').fill(registeredAccount.email);
      await page.getByLabel('Answer', { exact: true }).fill(registeredAccount.answer);
      await page.getByRole('button', { name: /Delete User Data/ }).click();
      const confirmation = page.getByText('Your erasure request will be processed shortly.', { exact: false });
      await expect(confirmation, 'Магазин подтвердил приём запроса').toBeVisible();
    });
    await test.step('Вернуться в магазин и проверить завершение сессии', async () => {
      await page.getByRole('link', { name: 'Go To HomePage' }).click();
      await openAccount(page);
      await expect(page.getByRole('menuitem', { name: 'Go to login page' }), 'После запроса магазин предлагает войти').toBeVisible();
    });
  });
});

test.describe('Заказы и оплата', () => {
  test.describe.configure({ timeout: 60_000 });

  test('Сохранённые адрес и карта доступны после повторного входа', async ({ signedInPage: page, registeredAccount }) => {
    await test.step('Сохранить адрес и карту', async () => {
      await saveAddress(page);
      await saveCard(page);
    });
    await test.step('Войти заново и выбрать сохранённые данные при оформлении', async () => {
      await logout(page);
      await login(page, registeredAccount);
      await startCheckout(page);
      await chooseAddressAndDelivery(page);
      const card = savedCardRow(page).getByRole('radio');
      await card.click();
      await expect(card, 'Сохранённая карта доступна для выбора').toBeChecked();
      await expect(page.getByRole('button', { name: 'Proceed to review' }), 'Можно перейти к проверке заказа').toBeEnabled();
    });
  });

  test('Баланс кошелька увеличивается после пополнения', async ({ signedInPage: page }) => {
    await saveCard(page);
    const balance = page.getByText('Wallet Balance', { exact: true }).locator('..').locator('.confirmation');
    const initialBalance = await test.step('Открыть кошелёк и запомнить текущий баланс', async () => {
      await openOrdersPage(page, 'Go to wallet page');
      await expect(balance, 'Отображается текущий баланс кошелька').toHaveText(/^\s*\d+(?:\.\d+)?\s*$/);
      return Number(await balance.textContent());
    });
    await test.step('Пополнить кошелёк тестовой картой на 20', async () => {
      await page.getByLabel('Enter an amount').fill('20');
      await page.getByRole('button', { name: 'Button to continue to payment' }).click();
      await savedCardRow(page).getByRole('radio').click();
      await page.getByRole('button', { name: 'Proceed to review' }).click();
    });
    await test.step('Проверить, что баланс увеличился на 20', async () => {
      await expect(page, 'После оплаты снова открылся кошелёк').toHaveURL(/#\/wallet$/);
      await expect.poll(async () => Number(await balance.textContent()), {
        message: 'Баланс кошелька вырос на сумму пополнения',
      }).toBe(initialBalance + 20);
    });
  });

  test('Оплаченный заказ появляется в истории с тем же номером и товаром', async ({ signedInPage: page }) => {
    await test.step('Подготовить адрес и карту', async () => {
      await saveAddress(page);
      await saveCard(page);
    });
    const orderId = await test.step('Оформить и оплатить заказ', async () => {
      await startCheckout(page);
      await chooseAddressAndDelivery(page);
      await savedCardRow(page).getByRole('radio').click();
      await page.getByRole('button', { name: 'Proceed to review' }).click();
      await page.getByRole('button', { name: 'Complete your purchase' }).click();
      const confirmation = page.getByRole('heading', { name: 'Thank you for your purchase!' });
      await expect(confirmation, 'Магазин подтвердил покупку').toBeVisible();
      await expect(page.getByText(appleJuice, { exact: true }), 'В подтверждении указан яблочный сок').toBeVisible();
      await expect(page, 'В адресе страницы подтверждения указан номер заказа').toHaveURL(/#\/order-completion\/[^/?#]+$/);
      return new URL(page.url()).hash.split('/').at(-1);
    });
    await test.step('Найти этот заказ и товар в истории', async () => {
      await openOrdersPage(page, 'Go to order history page');
      const orderNumber = page.getByText(`#${orderId}`, { exact: true });
      await expect(orderNumber, 'В истории указан номер оформленного заказа').toBeVisible();
      const order = page.locator('.table-container').filter({ has: orderNumber });
      await expect(order.getByText(appleJuice, { exact: true }), 'В этом заказе есть яблочный сок').toBeVisible();
    });
  });

  test('Заявка на переработку подтверждает вывоз 150 л на выбранную дату', async ({ signedInPage: page }) => {
    await saveAddress(page);
    await test.step('Открыть раздел переработки', () => openOrdersPage(page, 'Go to recycling page'));
    const pickupDate = new Date();
    pickupDate.setDate(pickupDate.getDate() + 7);
    const formattedDate = pickupDate.toLocaleDateString('en-US');

    await test.step('Указать объём, выбрать адрес и дату вывоза, отправить заявку', async () => {
      await page.getByPlaceholder('...in liters').fill('150');
      await page.getByRole('row').filter({ hasText: testAddress }).click();
      await page.getByRole('checkbox', { name: /Please pickup/ }).check();
      const dateField = page.getByLabel('Pickup Date', { exact: true });
      await dateField.fill(formattedDate);
      await dateField.blur();
      await page.locator('#recycleButton').click();
    });
    await test.step('Проверить, что магазин подтвердил вывоз на выбранную дату', async () => {
      await expect(page.locator('mat-snack-bar-container'), `Магазин подтверждает вывоз на ${formattedDate}`)
        .toContainText(`We will pick up your pomace on ${formattedDate}.`);
    });
  });
});
