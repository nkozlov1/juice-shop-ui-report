const { randomUUID } = require('node:crypto');
const { test: base, expect } = require('@playwright/test');

const shopUrl = 'http://localhost:3000';
const testAddress = '25 Test Orchard Road';
const testCard = '4242424242424242';
const appleJuice = 'Apple Juice (1000ml)';

const test = base.extend({
  account: [async ({}, use) => {
    await use({
      email: `workshop-${randomUUID()}@example.test`,
      password: 'Workshop!2026',
      question: 'Your favorite book?',
      answer: 'An Orchard for Testing',
    });
  }, { title: 'Данные тестового пользователя' }],
  registeredAccount: [async ({ page, account }, use) => {
    await register(page, account);
    await use(account);
  }, { title: 'Регистрация тестового пользователя' }],
  signedInPage: [async ({ page, registeredAccount }, use) => {
    await login(page, registeredAccount);
    await use(page);
  }, { title: 'Вход под тестовым пользователем' }],
});

test.use({ baseURL: shopUrl, locale: 'en-US' });

test.beforeEach(async ({ context }) => {
  await context.addCookies([
    { name: 'welcomebanner_status', value: 'dismiss', url: shopUrl },
    { name: 'cookieconsent_status', value: 'dismiss', url: shopUrl },
  ]);
});

async function openAccount(page) {
  await page.getByRole('button', { name: 'Show/hide account menu' }).click();
}

async function openAccountPage(page, item, submenu) {
  await openAccount(page);
  if (submenu) {
    await page.getByRole('menuitem', { name: submenu }).click();
  }
  await page.getByRole('menuitem', { name: item, exact: true }).click();
}

async function register(page, account) {
  await test.step('Открыть форму регистрации и дождаться загрузки контрольных вопросов', async () => {
    await page.goto('/#/login');
    const [questions] = await Promise.all([
      page.waitForResponse(response => new URL(response.url()).pathname === '/api/SecurityQuestions/'),
      page.getByRole('link', { name: 'Not yet a customer?' }).click(),
    ]);
    expect(questions.ok(), 'Список контрольных вопросов загрузился').toBe(true);
    await questions.finished();
  });
  await test.step('Указать почту, пароль и ответ на контрольный вопрос', async () => {
    await page.getByLabel('Email address field').fill(account.email);
    await page.getByLabel('Field for the password').fill(account.password);
    await page.getByLabel('Field to confirm the password').fill(account.password);
    await page.getByRole('combobox', { name: 'Selection list for the security question' }).click();
    await page.getByRole('option', { name: account.question }).click();
    await page.getByLabel('Field for the answer to the security question').fill(account.answer);
  });
  await test.step('Отправить форму и проверить переход на страницу входа', async () => {
    await page.getByRole('button', { name: 'Button to complete the registration' }).click();
    await expect(page, 'После регистрации открывается страница входа').toHaveURL(/#\/login$/);
    await expect(page.getByRole('button', { name: 'Login', exact: true }), 'Кнопка входа видна').toBeVisible();
  });
}

async function login(page, account, remember = false) {
  await test.step('Открыть форму входа и ввести почту и пароль', async () => {
    await page.goto('/#/login');
    await page.getByLabel('Text field for the login email').fill(account.email);
    await page.getByLabel('Text field for the login password').fill(account.password);
    await page.getByRole('checkbox', { name: 'Checkbox to stay logged in or not logged in' }).setChecked(remember);
  });
  await test.step('Войти и проверить, что открылся каталог', async () => {
    await page.getByRole('button', { name: 'Login', exact: true }).click();
    await expect(page, 'После входа открывается каталог').toHaveURL(/#\/search$/);
  });
}

async function logout(page) {
  await openAccountPage(page, 'Logout');
}

async function expectAccountEmail(page, email) {
  await openAccount(page);
  await expect(page.getByRole('menuitem', { name: 'Go to user profile' }), 'В меню аккаунта видна почта пользователя').toContainText(email);
  await page.keyboard.press('Escape');
}

async function openPrivacyPage(page, item) {
  await openAccountPage(page, item, 'Show Privacy and Security Menu');
}

async function openOrdersPage(page, item) {
  await openAccountPage(page, item, 'Show Orders and Payment Menu');
}

async function saveAddress(page) {
  await test.step('Добавить адрес в список сохранённых адресов', async () => {
    await openOrdersPage(page, 'Go to saved address page');
    await page.getByRole('button', { name: 'Add New Address' }).click();
    await page.getByLabel('Name', { exact: true }).fill('Workshop Buyer');
    await page.getByLabel('Country', { exact: true }).fill('United States');
    await page.getByLabel('Mobile Number', { exact: true }).fill('2025550144');
    await page.getByLabel('ZIP Code', { exact: true }).fill('10001');
    await page.getByLabel('Address', { exact: true }).fill(testAddress);
    await page.getByLabel('City', { exact: true }).fill('New York');
    await page.getByLabel('State', { exact: true }).fill('NY');
    await page.getByRole('button', { name: /Submit/ }).click();
    const address = page.getByRole('row').filter({ hasText: testAddress });
    await expect(address, 'Новый адрес появился в списке').toBeVisible();
  });
}

function savedCardRow(page) {
  return page.locator('mat-row').filter({ hasText: `************${testCard.slice(-4)}` });
}

async function saveCard(page) {
  await test.step('Добавить тестовую карту в список способов оплаты', async () => {
    await openOrdersPage(page, 'Go to saved payment methods page');
    await page.getByRole('button', { name: /Add new card/ }).click();
    await page.getByLabel('Name', { exact: true }).fill('Workshop Buyer');
    await page.getByLabel('Card Number', { exact: true }).fill(testCard);
    await page.getByLabel('Expiry Month', { exact: true }).selectOption('12');
    await page.getByLabel('Expiry Year', { exact: true }).selectOption({ index: 0 });
    await page.getByRole('button', { name: /Submit/ }).click();
    await expect(savedCardRow(page), 'Карта с нужными последними цифрами появилась в списке').toBeVisible();
  });
}

async function startCheckout(page) {
  await test.step('Добавить яблочный сок в корзину', async () => {
    await page.getByRole('button', { name: 'Back to homepage' }).click();
    const product = page.getByRole('article').filter({
      has: page.getByText(appleJuice, { exact: true }),
    });
    await product.getByLabel('Add to Basket').click();
  });
  await test.step('Проверить товар в корзине и начать оформление', async () => {
    await page.getByRole('button', { name: 'Show the shopping cart' }).click();
    await expect(page.getByText(appleJuice, { exact: true }), 'Яблочный сок отображается в корзине').toBeVisible();
    await page.locator('#checkoutButton').click();
  });
}

async function chooseAddressAndDelivery(page) {
  await test.step('Выбрать сохранённый адрес доставки', async () => {
    const address = page.getByRole('row').filter({ hasText: testAddress });
    await address.click();
    await page.getByRole('button', { name: 'Continue', exact: true }).click();
    await expect(page.getByText(new RegExp(testAddress)), 'На шаге доставки указан выбранный адрес').toBeVisible();
  });
  await test.step('Выбрать стандартную доставку и перейти к оплате', async () => {
    await page.getByText('Standard Delivery', { exact: true }).click();
    await page.getByRole('button', { name: 'Proceed to delivery method selection' }).click();
  });
}

module.exports = {
  test, expect, testAddress, appleJuice, register, login, logout, openAccount, openAccountPage,
  expectAccountEmail, openPrivacyPage, openOrdersPage, saveAddress, saveCard, savedCardRow,
  startCheckout, chooseAddressAndDelivery,
};
